from django.apps import AppConfig


class AutoApiConfig(AppConfig):
    name = 'auto_api'
