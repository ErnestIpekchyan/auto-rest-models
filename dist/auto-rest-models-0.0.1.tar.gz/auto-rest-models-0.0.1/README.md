# auto-rest-models
REST API for all models in project