# Auto-Rest-Models
Provides automatic REST API for models in Django project